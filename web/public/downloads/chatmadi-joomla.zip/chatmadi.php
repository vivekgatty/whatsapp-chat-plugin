﻿<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Plugin\CMSPlugin;

class PlgSystemChatmadi extends CMSPlugin {
    protected $app;

    public function onBeforeCompileHead() {
        $app = Factory::getApplication();
        if (!$app->isClient('site')) { return; }

        $doc = $app->getDocument();
        if (!($doc instanceof HtmlDocument)) { return; }

        $widgetId = trim((string) $this->params->get('widget_id', ''));
        $prechat  = (int) $this->params->get('prechat', 0);
        $waNumber = trim((string) $this->params->get('waNumber', ''));

        if ($widgetId === '') { return; }

        $url = 'https://chatmadi.com/api/widget.js?wid=' . rawurlencode($widgetId);
        if ($prechat) { $url .= '&prechat=on'; }
        if ($waNumber !== '') { $url .= '&waNumber=' . rawurlencode($waNumber); }

        $doc->addCustomTag('<script src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" async></script>');
    }
}
